import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { Button } from "@/pages/ui/button";
import { Card, CardContent } from "@/pages/ui/card";

const AyudasAdmin = () => {

  const navigate = useNavigate();
    const token = localStorage.getItem("auth-token");
    const rol = localStorage.getItem("rol");

    // Verificamos si el usuario tiene el rol adecuado
    if (!token || rol !== "administrador") {
        navigate("/login");  // Si no es administrador, redirigimos a login
        return null;
    }

  const [ayudas, setAyudas] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [mostrarModal, setMostrarModal] = useState(false);
  const [nuevoAyuda, setNuevoAyuda] = useState({
    nombre: "",
    fecha: "",
    lugar: "",
    monto: "",
    causa: "",
  });

  useEffect(() => {
    cargarAyudas();
  }, []);

  const cargarAyudas = () => {
    axios.get("http://localhost:8000/api/ayudas")
      .then((res) => {
        setAyudas(res.data);
        setCargando(false);
      })
      .catch((err) => {
        console.error("Error al cargar opciones de ayudas", err);
        setCargando(false);
      });
  };

  const handleCrearAyuda = (e) => {
    e.preventDefault();
    axios.post("http://localhost:8000/api/ayudas", nuevoAyuda)
      .then(() => {
        setMostrarModal(false);
        setNuevoAyuda({ nombre: "", fecha: "", lugar: "", monto: "", causa: "" });
        cargarAyudas();
      })
      .catch((err) => console.error("Error al crear opción donación", err));
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold">Gestión de Donaciones</h2>
        <button
  onClick={() => setMostrarModal(true)}

  className="bg-green-300 text-black p-2"
>
  Crear opción Donación
</button>

      </div>

      {cargando ? (
        <p>Cargando opciones...</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {ayudas.map((ayuda) => (
            <Card key={ayuda.id}>
              <CardContent>
                <h3 className="text-xl font-semibold">{ayuda.nombre}</h3>
                <p>📅 {ayuda.fecha}</p>
                <p>💰 {ayuda.monto}</p>
                <p>👩 {ayuda.causa}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Modal */}
      {mostrarModal && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl shadow-lg p-6 w-full max-w-md">
            <h3 className="text-xl font-bold mb-4">Nueva opción donación</h3>
            <form onSubmit={handleCrearAyuda} className="space-y-4">
              <input
                type="text"
                placeholder="Nombre de la Ayuda"
                value={nuevoAyuda.nombre}
                onChange={(e) => setNuevoAyuda({ ...nuevoAyuda, nombre: e.target.value })}
                className="w-full border p-2 rounded"
                required
              />
              <input
                type="date"
                value={nuevoAyuda.fecha}
                onChange={(e) => setNuevoAyuda({ ...nuevoAyuda, fecha: e.target.value })}
                className="w-full border p-2 rounded"
                required
              />
              <input
                type="text"
                placeholder="Lugar"
                value={nuevoAyuda.lugar}
                onChange={(e) => setNuevoAyuda({ ...nuevoAyuda, lugar: e.target.value })}
                className="w-full border p-2 rounded"
                required
              />
              <input
                type="text"
                placeholder="Monto"
                value={nuevoAyuda.monto}
                onChange={(e) => setNuevoAyuda({ ...nuevoAyuda, monto: e.target.value })}
                className="w-full border p-2 rounded"
                required
              />
              <input
                type="text"
                placeholder="Causa"
                value={nuevoAyuda.causa}
                onChange={(e) => setNuevoAyuda({ ...nuevoAyuda, causa: e.target.value })}
                className="w-full border p-2 rounded"
                required
              />
              <div className="flex justify-end gap-2">
              <button
  type="button"
  onClick={() => setMostrarModal(false)}
  className="bg-gray-200 text-black px-4 py-2 rounded hover:bg-gray-300"
>
  Cancelar
</button>
<button
  type="submit"
  className="bg-red-900 text-white px-4 py-2 rounded hover:bg-red-800"
>
  Guardar
</button>

              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AyudasAdmin;