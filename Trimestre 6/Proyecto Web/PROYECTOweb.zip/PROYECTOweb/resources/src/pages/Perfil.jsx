// resources/src/pages/Perfil.jsx

import React from "react";

export default function Perfil() {
    return (
        <div className="container py-5">
            <h1>Tu Perfil</h1>
            <p>Aquí puedes ver y editar tu información personal.</p>
            <div>
                <h3>Información del Usuario</h3>
                {/* Aquí puedes mostrar el nombre, correo y otros datos del usuario */}
            </div>
        </div>
    );
}
