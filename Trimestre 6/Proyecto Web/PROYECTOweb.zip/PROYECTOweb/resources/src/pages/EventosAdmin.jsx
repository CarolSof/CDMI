// resources/src/pages/EventosAdmin.jsx
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { Button } from "@/pages/ui/button";
import { Card, CardContent } from "@/pages/ui/card";

const EventosAdmin = () => {

  const navigate = useNavigate();
    const token = localStorage.getItem("auth-token");
    const rol = localStorage.getItem("rol");

    // Verificamos si el usuario tiene el rol adecuado
    if (!token || rol !== "administrador") {
        navigate("/login");  // Si no es administrador, redirigimos a login
        return null;
    }

  const [eventos, setEventos] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [mostrarModal, setMostrarModal] = useState(false);
  const [nuevoEvento, setNuevoEvento] = useState({
    nombre: "",
    fecha: "",
    lugar: "",
  });

  useEffect(() => {
    cargarEventos();
  }, []);

  const cargarEventos = () => {
    axios.get("http://localhost:8000/api/eventos")
      .then((res) => {
        setEventos(res.data);
        setCargando(false);
      })
      .catch((err) => {
        console.error("Error al cargar eventos", err);
        setCargando(false);
      });
  };

  const handleCrearEvento = (e) => {
    e.preventDefault();
    axios.post("http://localhost:8000/api/eventos", nuevoEvento)
      .then(() => {
        setMostrarModal(false);
        setNuevoEvento({ nombre: "", fecha: "", lugar: "" });
        cargarEventos();
      })
      .catch((err) => console.error("Error al crear evento", err));
  };

  return (
    <div className="p-6" style={{ fontFamily:"Merriweather, serif", backgroundColor:"#e1c699", color: "#FFFF", padding: "2rem" }}>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold">Gestión de Eventos</h2>
        <button
  onClick={() => setMostrarModal(true)}

  className="bg-green-300 text-black p-2"
  style={{ zIndex: 9999, position: 'relative', backgroundColor: '#ffff', // dorado
    color: 'black',
    border: '2px solid #ffff' }}
>
  Crear evento
</button>

      </div>

      {cargando ? (
        <p>Cargando eventos...</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4" >
          {eventos.map((evento) => (
            <Card key={evento.id}>
              <CardContent>
                <h3 className="text-xl font-semibold" style={{ color: "#000"}}>{evento.nombre}</h3>
                <p style={{ color: "#000"}}>Fecha: {evento.fecha}</p>
                <p style={{ color: "#000"}}>Lugar: {evento.lugar}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Modal */}
      {mostrarModal && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl shadow-lg p-6 w-full max-w-md">
            <h3 className="text-xl font-bold mb-4">Nuevo Evento</h3>
            <form onSubmit={handleCrearEvento} className="space-y-4">
              <input
                type="text"
                placeholder="Nombre del evento"
                value={nuevoEvento.nombre}
                onChange={(e) => setNuevoEvento({ ...nuevoEvento, nombre: e.target.value })}
                className="w-full border p-2 rounded"
                required
              />
              <input
                type="date"
                value={nuevoEvento.fecha}
                onChange={(e) => setNuevoEvento({ ...nuevoEvento, fecha: e.target.value })}
                className="w-full border p-2 rounded"
                required
              />
              <input
                type="text"
                placeholder="Lugar"
                value={nuevoEvento.lugar}
                onChange={(e) => setNuevoEvento({ ...nuevoEvento, lugar: e.target.value })}
                className="w-full border p-2 rounded"
                required
              />
              <div className="flex justify-end gap-2">
              <button
  type="button"
  onClick={() => setMostrarModal(false)}
  className="bg-gray-200 text-black px-4 py-2 rounded hover:bg-gray-300"
  style={{ zIndex: 9999, position: 'relative', backgroundColor: '#e1c699', // dorado
    color: 'black',
    border: '2px solid #ffff' }}
>
  Cancelar
</button>
<button
  type="submit"
  className="bg-red-900 text-black px-4 py-2 rounded hover:bg-red-800"
  style={{ zIndex: 9999, position: 'relative', backgroundColor: '#e1c699', // dorado
    color: 'black',
    border: '2px solid #ffff' }}
>
  Guardar
</button>

              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default EventosAdmin;

{/*import React, { useState, useEffect } from "react";
import axios from "axios";
import { Button } from "@/pages/ui/button";
import { Card, CardContent } from "@/pages/ui/card";

const EventosAdmin = () => {
  const [eventos, setEventos] = useState([]);
  const [cargando, setCargando] = useState(true);


  // Simulación de carga inicial (luego lo conectamos al backend)
  useEffect(() => {
    axios.get("http://localhost:8000/api/eventos")
      .then((res) => {
        setEventos(res.data);
        setCargando(false);
      })
      .catch((err) => {
        console.error("Error al cargar eventos", err);
        setCargando(false);
      });
    
    const eventosDummy = [
      { id: 1, nombre: "Feria de Ciencia", fecha: "2025-05-10", lugar: "Auditorio Central" },
      { id: 2, nombre: "Hackathon RECIENCIA", fecha: "2025-06-01", lugar: "Sala 2" },
    ];
    setEventos(eventosDummy);
  }, []);

  const handleEditar = (id) => {
    console.log("Editar evento", id);
    // lógica de navegación o abrir modal
  };

  const handleEliminar = (id) => {
    console.log("Eliminar evento", id);
    // lógica de confirmación y eliminación
  };

  const handleCrearNuevo = () => {
    console.log("Crear nuevo evento");
    // lógica para abrir formulario o redirigir
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Gestión de Eventos</h1>

      <Button className="mb-4" onClick={handleCrearNuevo}>
        Crear nuevo evento
      </Button>

      <Card>
        <CardContent className="overflow-x-auto p-4">
          <table className="min-w-full table-auto border">
            <thead>
              <tr className="bg-gray-100">
                <th className="px-4 py-2 text-left">Nombre</th>
                <th className="px-4 py-2 text-left">Fecha</th>
                <th className="px-4 py-2 text-left">Lugar</th>
                <th className="px-4 py-2 text-left">Acciones</th>
              </tr>
            </thead>
            <tbody>
              {eventos.map((evento) => (
                <tr key={evento.id} className="border-t">
                  <td className="px-4 py-2">{evento.nombre}</td>
                  <td className="px-4 py-2">{evento.fecha}</td>
                  <td className="px-4 py-2">{evento.lugar}</td>
                  <td className="px-4 py-2">
                    <Button className="mr-2" onClick={() => handleEditar(evento.id)}>
                      Editar
                    </Button>
                    <Button variant="destructive" onClick={() => handleEliminar(evento.id)}>
                      Eliminar
                    </Button>
                  </td>
                </tr>
              ))}
              {eventos.length === 0 && (
                <tr>
                  <td colSpan="4" className="text-center py-4">
                    No hay eventos registrados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
};

export default EventosAdmin;*/}
