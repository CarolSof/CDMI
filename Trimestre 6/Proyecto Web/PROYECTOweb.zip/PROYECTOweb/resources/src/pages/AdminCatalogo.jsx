import React, { useState, useEffect } from 'react';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import { Button } from "@/pages/ui/button";
import { Card, CardContent } from "@/pages/ui/card";

const AdminCatalogo = () => {

    const navigate = useNavigate();
        const token = localStorage.getItem("auth-token");
        const rol = localStorage.getItem("rol");

    // Verificamos si el usuario tiene el rol adecuado
    if (!token || rol !== "administrador") {
        navigate("/login");  // Si no es administrador, redirigimos a login
        return null;
    }

  const [inventarios, setInventarios] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [mostrarModal, setMostrarModal] = useState(false);
  const [nuevoInventario, setNuevoInventario] = useState({
    nombre: "",
    descripcion: "",
    precio: "",
  });

  useEffect(() => {
    cargarInventarios();
  }, []);

  const cargarInventarios = () => {
    axios.get("http://localhost:8000/api/inventarios")
      .then((res) => {
        setInventarios(res.data);
        setCargando(false);
      })
      .catch((err) => {
        console.error("Error al cargar producto", err);
        setCargando(false);
      });
  };

  const handleCrearInventario = (e) => {
    e.preventDefault();
    axios.post("http://localhost:8000/api/inventarios", nuevoInventario)
      .then(() => {
        setMostrarModal(false);
        setNuevoInventario({ nombre: "", descripcion: "", precio: "" });
        cargarInventarios();
      })
      .catch((err) => console.error("Error al crear producto", err));
  };

  {/*
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('/api/mercancias', { nombre, descripcion, precio });
      setMensaje('Automóvil registrado exitosamente');
      setNombre('');
      setDescripcion('');
      setPrecio('');
    } catch (error) {
      console.error(error);
      setMensaje('Error al registrar automóvil');
    }
  };*/}

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold">Gestión del carrito</h2>
        <button
  onClick={() => setMostrarModal(true)}

  className="bg-green-300 text-black p-2"
>
  Crear producto
</button>

      </div>

      {cargando ? (
        <p>Cargando productos...</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {inventarios.map((inventario) => (
            <Card key={inventario.id}>
              <CardContent>
                <h3 className="text-xl font-semibold">{inventario.nombre}</h3>
                <p>🛒 {inventario.nombre}</p>
                <p>🖊️ {inventario.descripcion}</p>
                <p>💰 {inventario.precio}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Modal */}
      {mostrarModal && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl shadow-lg p-6 w-full max-w-md">
            <h3 className="text-xl font-bold mb-4">Nuevo producto</h3>
            <form onSubmit={handleCrearInventario} className="space-y-4">
              <input
                type="text"
                placeholder="Nombre del producto"
                value={nuevoInventario.nombre}
                onChange={(e) => setNuevoInventario({ ...nuevoInventario, nombre: e.target.value })}
                className="w-full border p-2 rounded"
                required
              />
              <input
                type="text"
                placeholder="Descripción"
                value={nuevoInventario.descripcion}
                onChange={(e) => setNuevoInventario({ ...nuevoInventario, descripcion: e.target.value })}
                className="w-full border p-2 rounded"
                required
              />
              <input
                type="text"
                placeholder="Precio"
                value={nuevoInventario.precio}
                onChange={(e) => setNuevoInventario({ ...nuevoInventario, precio: e.target.value })}
                className="w-full border p-2 rounded"
                required
              />
              <div className="flex justify-end gap-2">
              <button
  type="button"
  onClick={() => setMostrarModal(false)}
  className="bg-gray-200 text-black px-4 py-2 rounded hover:bg-gray-300"
>
  Cancelar
</button>
<button
  type="submit"
  className="bg-red-900 text-white px-4 py-2 rounded hover:bg-red-800"
>
  Guardar
</button>

              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminCatalogo;
