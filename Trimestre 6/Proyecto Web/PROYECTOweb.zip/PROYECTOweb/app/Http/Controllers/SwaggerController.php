<?php

namespace App\Http\Controllers;

/**
 * @OA\Info(
 *     version="1.0.0",
 *     title="Documentación de la API",
 *     description="Documentación de la API proyecto CDMI",
 *     @OA\Contact(
 *         email="tucorreo@ejemplo.com"
 *     )
 * )
 */
class SwaggerController extends Controller
{
    //
}