// hooks/useGetSession.ts
import { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function useGetSession() {
  const [userSession, setUserSession] = useState<{ token: string; rol: string } | null>(null);

  useEffect(() => {
    const loadSession = async () => {
      const token = await AsyncStorage.getItem('auth-token');
      const rol = await AsyncStorage.getItem('rol');
      if (token && rol) {
        setUserSession({ token, rol });
      }
    };

    loadSession();
  }, []);

  const handleLogout = async () => {
    await AsyncStorage.removeItem('auth-token');
    await AsyncStorage.removeItem('rol');
    setUserSession(null);
  };

  return { userSession, handleLogout };
}
