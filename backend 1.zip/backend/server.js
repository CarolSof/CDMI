const express = require('express')
const mysql = require("mysql2")
const bodyParser = require("body-parser")

const app = express()

app.use(function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*')
    res.setHeader('Access-Control-Allow-Methods', '*')
    next()
})


app.use(bodyParser.json())

const PUERTO = 3000

const conexion = mysql.createConnection(
    {
        host: 'localhost',
        database: 'prueba',
        user: 'root',
        password: ''
    }

)


app.listen(PUERTO, () => {
    console.log(" Este Servidor esta corriendo en el puerto No. ", PUERTO)
})


conexion.connect(error => {
    if (error) throw error
    console.log("Conexion Satisfactoria a MySQL")
})

app.get('/', (req, res) => {
    res.send('Mi Primer API  26 Marzo')
})

app.get('/api/usuarios/login', (req, res) => {
    res.send("Esta Api permite hacer Login")
})



app.get('/api/usuarios/listar', (req, res) => {
    const sql = 'SELECT * FROM usuarios_'
    conexion.query(sql, (error, resultado) => {
        if (error) return console.error(error.message)

        if (resultado.length > 0) {
            res.json(resultado)
            console.log(res.json(resultado))
        } else {
            res.json('No hay registros')

        }
    })
})


app.get('/productos', (request, response) => {
    conexion.query("SELECT * FROM usuarios_",
        (error, results) => {
            if (error)
                throw error;
            response.status(204).json(results);
        });
});


app.get('/api/usuarios/:id', (req, res) => {
    const { id } = req.params
    const query = `SELECT * FROM usuarios_ WHERE id_usuario=${id}`
    conexion.query(query, (error, resultado) => {
        if (error) return console.error(error.message)

        if (resultado.length > 0) {
            res.json(resultado)
            console.log(res.json(resultado))
        } else {
            res.json('No hay registros con ese ID')

        }
    })
});

app.post('/api/usuarios/agregar', (req, res) => {

    const { nombre, correo, clave } = req.body;
    if (!nombre || !correo || !clave) {
        return res.status(400).json({ error: "Todos los campos son obligatorios" });
    } else {
        const sql = 'INSERT INTO usuarios_ (nombre, correo, clave) VALUES (?, ?, ?)';
        conexion.query(sql, [nombre, correo, clave], (error, result) => {
            if (error) {
                if (error.code === 'ER_DUP_ENTRY') {
                    return res.status(400).json({ error: "El correo ya está registrado" });
                }
                return res.status(500).json({ error: "Error al insertar usuario" });
            }
            res.status(201).json({ message: "Usuario agregado", id: result.insertId });
        });
    }


});

app.delete('/api/usuarios/eliminar/:id', (req, res) => {
    const { id } = req.params;
    const sql = 'DELETE FROM usuarios_ WHERE id_usuario = ?';

    conexion.query(sql, [id], (error, result) => {
        if (error) return res.status(500).json({ error: "Error al eliminar usuario" });
        if (result.affectedRows === 0) return res.status(404).json({ message: "Usuario no encontrado" });

        res.json({ message: "Usuario eliminado" });
    });
});

app.put('/api/usuarios/editar/:id', (req, res) => {
    const { id } = req.params;
    const { nombre, correo, clave } = req.body;

    if (!nombre || !correo) {
        return res.status(400).json({ error: "Nombre y correo son obligatorios" });
    }

    let sql = 'UPDATE usuarios_ SET nombre = ?, correo = ?';
    let values = [nombre, correo];

    if (clave) {
        sql += ', clave = ?';
        values.push(clave);
    }

    sql += ' WHERE id_usuario = ?';
    values.push(id);

    conexion.query(sql, values, (error, result) => {
        if (error) return res.status(500).json({ error: "Error al actualizar usuario" });
        if (result.affectedRows === 0) return res.status(404).json({ message: "Usuario no encontrado" });

        res.json({ message: "Usuario actualizado" });
    });
});